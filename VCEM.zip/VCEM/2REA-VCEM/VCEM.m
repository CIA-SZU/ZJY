function Offspring = VCEM(Global,Parent,CV,DV,Sc,Sd)
% <operator> <real>
%
% proC ---  1 --- The probability of doing crossover
% disC --- 20 --- The distribution index of simulated binary crossover
% proM ---  1 --- The expectation of number of bits doing mutation
% disM --- 20 --- The distribution index of polynomial mutation

%--------------------------------------------------------------------------
% Copyright (c) 2016-2017 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB Platform
% for Evolutionary Multi-Objective Optimization [Educational Forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------
p=0.5;
[proC,disC,proM,disM] = Global.ParameterSet(1,20,1,20);
Parent    = Parent([1:end,1:ceil(end/2)*2-end]);
ParentDec = Parent.decs;
[N,D]     = size(ParentDec);

%% Simulated binary crossover
Parent1Dec = ParentDec(1:N/2,:);
Parent2Dec = ParentDec(N/2+1:end,:);
beta = zeros(N/2,D);
mu   = rand(N/2,D);
beta(mu<=0.5) = (2*mu(mu<=0.5)).^(1/(disC+1));
beta(mu>0.5)  = (2-2*mu(mu>0.5)).^(-1/(disC+1));
beta = beta.*(-1).^randi([0,1],N/2,D);
beta(rand(N/2,D)<0.5) = 1;
beta(repmat(rand(N/2,1)>proC,1,D)) = 1;
OffspringDec = [(Parent1Dec+Parent2Dec)/2+beta.*(Parent1Dec-Parent2Dec)/2
    (Parent1Dec+Parent2Dec)/2-beta.*(Parent1Dec-Parent2Dec)/2];


%% VCEM 
for i=1:Global.N
    pp=rand;
    if pp<=p
        %convergence mutation
        if ~isempty(CV)
            xxx=unidrnd(length(CV));
            v=CV(xxx);%random seletct a variable
            OffspringDec(i,v)=Sc(v);
        end
        %diversity mutation
    else
        if ~isempty(DV) 
            [a1,~]=size(Sd);
            s1=randi(a1);       
            OffspringDec(i,DV)=Sd(s1,DV);
        end
    end
end
% addd noise
Lower = repmat(Global.lower,N,1);
Upper = repmat(Global.upper,N,1);
Site  = rand(N,D) < proM/D;
mu    = rand(N,D);
ff=randn(N,D);
temp  = Site & mu<=0.5;
para=0.01;
OffspringDec(temp) = OffspringDec(temp)+sqrt(para).*ff(temp).*(Upper(temp)-Lower(temp));
temp = Site & mu>0.5;
OffspringDec(temp) = OffspringDec(temp)-sqrt(para).*ff(temp).*(Upper(temp)-Lower(temp));

Offspring = INDIVIDUAL(OffspringDec);

end