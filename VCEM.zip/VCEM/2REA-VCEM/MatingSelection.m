function MatingPool = MatingSelection(PopObj,N,z,znad,dk)
    % Normalization
   PopObj = (PopObj-repmat(z,size(PopObj,1),1))./repmat(znad-z ,size(PopObj,1),1);    
   C=Convergence_Calculate(PopObj);    
   for i = 1 : N
       Index = randperm(N,2);
       if C(Index(1))<C(Index(2)) & dk(Index(1))<dk(Index(2))
           MatingPool(i) = Index(1);
       elseif C(Index(1))>C(Index(2)) & dk(Index(1))>dk(Index(2))
           MatingPool(i) = Index(2);
       else
           if rand()<0.5
               MatingPool(i) = Index(1);
           else
               MatingPool(i) = Index(2);
           end
       end
   end
end

function [C]=Convergence_Calculate(PopObj)      
     C= sum(PopObj,2);
end
