function TwoREAVCEM(Global)
% <algorithm> <A-G>
% A Many-Objective Evolutionary Algorithm Based On A Two-Round-Selection Strategy
    Population   = Global.Initialization();
    [z,znad]     = deal(min(Population.objs),max(Population.objs));
    [nSel,nPer,~] = Global.ParameterSet(10,5,5);
    %%  Variable Classification
    [DV,CV] = VariableClustering(Global,Population,nSel,nPer);
    %% Optimization
     while Global.NotTermination(Population)  
         %normalize
         PopObj = Population.objs;
         Zmin   = min(PopObj,[],1);
         Zmax   = max(PopObj,[],1);
         PopObj = (PopObj-repmat(Zmin,size(PopObj,1),1))./repmat(Zmax-Zmin,size(PopObj,1),1);
         %sum
         c= sum((PopObj),2);
         [~, bb]=sort(c);
         %cosine  similarity
         d  = pdist2(PopObj,PopObj,'cosine');
         d  = sort(d,2);
        dk = 1./(sum(d(:,2:ceil(end/10)),2)+1);  
        %get elite individual
        [~,b]=sort(dk);
        a1=length(Population);
        Sc=Population(bb(1)).dec;  
        Sd=Population(b(1:fix(a1/2))).decs;       
        MatingPool=MatingSelection(Population.objs,Global.N,z,znad,dk); 
        Offspring = VCEM(Global,Population(MatingPool),CV,DV,Sc,Sd);  
        Lp= Shape_Estimate(Population,Global.N,z,znad);
        [Population,z,znad] = EnvironmentalSelection([Population,Offspring],Global.N,Lp);
     end
end