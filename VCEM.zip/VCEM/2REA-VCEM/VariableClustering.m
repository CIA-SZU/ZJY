function [DV,CV] = VariableClustering(Global,Population,nSel,nPer)
% Detect the kind of each decision variable

%--------------------------------------------------------------------------
% Copyright (c) 2016-2017 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB Platform
% for Evolutionary Multi-Objective Optimization [Educational Forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    [N,D] = size(Population.decs);
    ND    = NDSort(Population.objs,1) == 1;
    fmin  = min(Population(ND).objs,[],1);
    fmax  = max(Population(ND).objs,[],1);
    
    %% Calculate the proper values of each decision variable
    Angle  = zeros(D,nSel);
    RMSE   = zeros(D,nSel);
    Sample = randi(N,1,nSel);
    PopObj = Population.objs;
    Zmin   = min(PopObj,[],1);
    Zmax   = max(PopObj,[],1);
    PopObj = (PopObj-repmat(Zmin,size(PopObj,1),1))./repmat(Zmax-Zmin,size(PopObj,1),1);
    po=PopObj(Sample,:);
    pov=(sqrt(sum((po).^2,2)))';
    pov=repmat(pov,D,1);
    for i = 1 : D %ÿ�����߱���
        drawnow();
        % Generate several random solutions by perturbing the i-th dimension
        Decs      = repmat(Population(Sample).decs,nPer,1);
        Decs(:,i) = rand(size(Decs,1),1)*(Global.upper(i)-Global.lower(i)) + Global.lower(i);
        newPopu   = INDIVIDUAL(Decs); %�����¸���
        dis(i)=0;
        for j = 1 : nSel
            % Normalize the objective values of the current perturbed solutions
            Points = newPopu(j:nSel:end).objs;
            PopObj=Points;
            PopObj = (PopObj-repmat(Zmin,size(PopObj,1),1))./repmat(Zmax-Zmin,size(PopObj,1),1);
            dis(i,j) =mean(sqrt(sum((PopObj).^2,2)));
            Points = (Points-repmat(fmin,size(Points,1),1))./repmat(fmax-fmin,size(Points,1),1);
            Points = Points - repmat(mean(Points,1),nPer,1);
  
            % Calculate the direction vector of the determining line
            [~,~,V] = svd(Points);
            Vector  = V(:,1)'./norm(V(:,1)');
            % Calculate the root mean square error
            error = zeros(1,nPer);
            for k = 1 : nPer
                error(k) = norm(Points(k,:)-sum(Points(k,:).*Vector)*Vector);
            end
            RMSE(i,j) = sqrt(sum(error.^2));
            % Calculate the angle between the line and the hyperplane
            normal     = ones(1,size(Vector,2));
            sine       = abs(sum(Vector.*normal,2))./norm(Vector)./norm(normal);
            Angle(i,j) = real(asin(sine)/pi*180);
        end
    end
    
    %% Detect the kind of each decision variable
    %f=mean(RMSE,2)
    VariableKind = (mean(RMSE,2)<0.01)';
    result       = kmeans(Angle,2)';
    if any(result(VariableKind)==1) && any(result(VariableKind)==2)
        if mean(mean(Angle(result==1&VariableKind,:))) > mean(mean(Angle(result==2&VariableKind,:)))
            VariableKind = VariableKind & result==1;
        else
            VariableKind = VariableKind & result==2;
        end
    end
   
    DV = find(~VariableKind);
    CV = find(VariableKind);
    if isempty(CV)% no convergence-related variables  
    % only kmean test
     aan=mean(Angle,2);
     a1=find(result==1);
     a2=find(result==2);
      if mean(aan(a1))<mean(aan(a2))
          VariableKind(a1)=0;
          VariableKind(a2)=1;
      else
           VariableKind(a1)=1;
          VariableKind(a2)=0;
      end
    end
      DV = find(~VariableKind);
      CV = find(VariableKind);
end